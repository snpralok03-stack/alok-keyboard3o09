package com.alok.keyboard.transform

import org.junit.Assert.assertEquals
import org.junit.Test

class TextTransformerTest {

    @Test
    fun testAlokTransformations() {
        val word = "alok"
        assertEquals("a l o k", TextTransformer.transform(word, TransformType.MONO))
        assertEquals("aa ll oo kk", TextTransformer.transform(word, TransformType.BANANA))
        assertEquals("AlOk", TextTransformer.transform(word, TransformType.ALTERNATE))
        assertEquals("kola", TextTransformer.transform(word, TransformType.REVERSE))
        assertEquals("aallookk", TextTransformer.transform(word, TransformType.CHIPKU))
    }

    @Test
    fun testHelloTransformations() {
        val word = "hello"
        assertEquals("h e l l o", TextTransformer.transform(word, TransformType.MONO))
        assertEquals("hh ee ll ll oo", TextTransformer.transform(word, TransformType.BANANA))
        assertEquals("HeLlO", TextTransformer.transform(word, TransformType.ALTERNATE))
        assertEquals("olleh", TextTransformer.transform(word, TransformType.REVERSE))
        assertEquals("hheelllloo", TextTransformer.transform(word, TransformType.CHIPKU))
    }

    @Test
    fun testIndiaTransformations() {
        val word = "india"
        assertEquals("i n d i a", TextTransformer.transform(word, TransformType.MONO))
        assertEquals("ii nn dd ii aa", TextTransformer.transform(word, TransformType.BANANA))
        assertEquals("InDiA", TextTransformer.transform(word, TransformType.ALTERNATE))
        assertEquals("aidni", TextTransformer.transform(word, TransformType.REVERSE))
        assertEquals("iinnddiiaa", TextTransformer.transform(word, TransformType.CHIPKU))
    }

    @Test
    fun testComputerTransformations() {
        val word = "computer"
        assertEquals("c o m p u t e r", TextTransformer.transform(word, TransformType.MONO))
        assertEquals("cc oo mm pp uu tt ee rr", TextTransformer.transform(word, TransformType.BANANA))
        assertEquals("CoMpUtEr", TextTransformer.transform(word, TransformType.ALTERNATE))
        assertEquals("retupmoc", TextTransformer.transform(word, TransformType.REVERSE))
        assertEquals("ccoommppuutteerr", TextTransformer.transform(word, TransformType.CHIPKU))
    }

    @Test
    fun testUppercaseHelloTransformations() {
        val word = "HELLO"
        assertEquals("H E L L O", TextTransformer.transform(word, TransformType.MONO))
        assertEquals("HH EE LL LL OO", TextTransformer.transform(word, TransformType.BANANA))
        assertEquals("HeLlO", TextTransformer.transform(word, TransformType.ALTERNATE))
        assertEquals("OLLEH", TextTransformer.transform(word, TransformType.REVERSE))
        assertEquals("HHEELLLLOO", TextTransformer.transform(word, TransformType.CHIPKU))
    }

    @Test
    fun testWordExtractionBeforeCursor() {
        assertEquals("alok", TextTransformer.extractCurrentWordBeforeCursor("namaste alok"))
        assertEquals("HELLO", TextTransformer.extractCurrentWordBeforeCursor("Testing HELLO"))
        assertEquals("", TextTransformer.extractCurrentWordBeforeCursor("hello "))
    }
}
