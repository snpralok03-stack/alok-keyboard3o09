package com.alok.keyboard.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.alok.keyboard.R
import com.alok.keyboard.transform.TextTransformer
import com.alok.keyboard.transform.TransformType

class SetupActivity : AppCompatActivity() {
    private lateinit var input: EditText
    private lateinit var result: TextView
    private var latestResult: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup)

        input = findViewById(R.id.et_test_sandbox)
        result = findViewById(R.id.tv_result)

        bindTransform(R.id.btn_mono, TransformType.MONO)
        bindTransform(R.id.btn_banana, TransformType.BANANA)
        bindTransform(R.id.btn_alternate, TransformType.ALTERNATE)
        bindTransform(R.id.btn_reverse, TransformType.REVERSE)
        bindTransform(R.id.btn_chipku, TransformType.CHIPKU)

        findViewById<Button>(R.id.btn_copy).setOnClickListener {
            if (latestResult.isBlank()) {
                Toast.makeText(this, "Pehle koi style choose karo", Toast.LENGTH_SHORT).show()
            } else {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Alok transformed text", latestResult))
                Toast.makeText(this, "Copied! Ab Gboard mein paste kar do.", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btn_use_result).setOnClickListener {
            if (latestResult.isNotEmpty()) {
                input.setText(latestResult)
                input.setSelection(input.text.length)
                input.requestFocus()
                showGboard()
            }
        }

        findViewById<Button>(R.id.btn_clear_sandbox).setOnClickListener {
            input.text.clear()
            latestResult = ""
            result.text = "Your transformed text will appear here"
            input.requestFocus()
            showGboard()
        }

        input.requestFocus()
    }

    private fun bindTransform(buttonId: Int, type: TransformType) {
        findViewById<Button>(buttonId).setOnClickListener {
            val source = input.text?.toString().orEmpty()
            if (source.isBlank()) {
                Toast.makeText(this, "Pehle text type karo", Toast.LENGTH_SHORT).show()
                input.requestFocus()
                showGboard()
                return@setOnClickListener
            }
            latestResult = transformText(source, type)
            result.text = latestResult
        }
    }

    // Transform each whitespace-separated word independently, preserving spacing.
    private fun transformText(source: String, type: TransformType): String {
        val out = StringBuilder(source.length * 2)
        var index = 0
        while (index < source.length) {
            if (source[index].isWhitespace()) {
                out.append(source[index])
                index++
            } else {
                val start = index
                while (index < source.length && !source[index].isWhitespace()) index++
                out.append(TextTransformer.transform(source.substring(start, index), type))
            }
        }
        return out.toString()
    }

    private fun showGboard() {
        input.post {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
        }
    }
}
